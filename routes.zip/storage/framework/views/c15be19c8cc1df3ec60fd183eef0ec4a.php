
<?php $__env->startSection('title', 'Quiz'); ?>

<?php $__env->startSection('content'); ?>
    <h2><?php echo e($task->title); ?>: Quiz</h2>
    <p class="text-secondary">Pass korte 70% lagbe.</p>

    <form method="POST" action="<?php echo e(route('student.quest.submit', $task->id)); ?>">
        <?php echo csrf_field(); ?>

        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="q-card">
                <strong>Q<?php echo e($i + 1); ?>. <?php echo e($q['question']); ?></strong>

                <?php $__currentLoopData = $q['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j => $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check mt-2">
                        <input class="form-check-input" type="radio"
                               name="answers[<?php echo e($i); ?>]" value="<?php echo e($j); ?>"
                               id="q<?php echo e($i); ?>o<?php echo e($j); ?>" required>
                        <label class="form-check-label" for="q<?php echo e($i); ?>o<?php echo e($j); ?>"><?php echo e($opt); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="d-flex gap-2">
            <a href="<?php echo e(route('student.quest.show', $task->id)); ?>" class="btn btn-outline-secondary">← Lesson</a>
            <button type="submit" class="btn btn-primary">Submit Quiz</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('quest.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gamified-education\resources\views/quest/quiz.blade.php ENDPATH**/ ?>