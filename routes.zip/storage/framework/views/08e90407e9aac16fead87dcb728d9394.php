<?php ($questions = data_get($task->game_data, 'questions', [])); ?>
<?php echo $__env->make('student.games.partials.multiple-choice-quiz', [
    'gameLabel' => 'ART · COLOR THEORY QUEST',
    'gameIcon' => '🎨',
    'accentColor' => '#e879f9',
    'supportingCopy' => 'Explore color relationships and build your visual eye.',
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\xampp\htdocs\gamified-education\resources\views/student/games/art-color-theory.blade.php ENDPATH**/ ?>