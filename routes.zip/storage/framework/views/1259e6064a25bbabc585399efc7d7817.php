<?php ($questions = data_get($task->game_data, 'questions', [])); ?>
<?php echo $__env->make('student.games.partials.multiple-choice-quiz', [
    'gameLabel' => 'MUSIC · NOTES & RHYTHM QUEST',
    'gameIcon' => '🎵',
    'accentColor' => '#38bdf8',
    'supportingCopy' => 'Train your ear for notes, rhythm, and musical patterns.',
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\xampp\htdocs\gamified-education\resources\views/student/games/music-note-rhythm.blade.php ENDPATH**/ ?>