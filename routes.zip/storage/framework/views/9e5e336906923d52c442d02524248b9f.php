

<?php $__env->startSection('title', $learningMaterial->title . ' | Learning Materials'); ?>

<?php $__env->startSection('head'); ?>
<style>
    .material-page {
        min-height: 100vh;
        padding: 28px 30px 60px;
        color: var(--text-main);
    }

    .material-hero,
    .material-panel {
        background: linear-gradient(145deg, var(--surface), var(--surface-alt));
        border: 1px solid var(--border);
        border-radius: 22px;
        box-shadow: 0 14px 34px rgba(0, 0, 0, 0.14);
    }

    .material-hero {
        position: relative;
        overflow: hidden;
        margin-bottom: 24px;
    }

    .material-hero::after {
        content: '';
        position: absolute;
        width: 260px;
        height: 260px;
        right: -90px;
        top: -130px;
        border-radius: 50%;
        background: var(--glow);
        opacity: 0.18;
        pointer-events: none;
    }

    .material-hero-image {
        display: block;
        width: 100%;
        max-height: 360px;
        object-fit: cover;
    }

    .material-hero-copy {
        position: relative;
        z-index: 1;
        padding: 30px clamp(22px, 4vw, 44px) 34px;
    }

    .material-back-link {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 22px;
        color: var(--text-muted);
        font-size: 0.88rem;
        font-weight: 700;
        text-decoration: none;
        transition: color 0.2s ease;
    }

    .material-back-link:hover,
    .material-back-link:focus-visible {
        color: var(--secondary);
    }

    .material-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 14px;
        color: var(--secondary);
        font-size: 0.76rem;
        font-weight: 800;
        letter-spacing: 0.12em;
        text-transform: uppercase;
    }

    .material-meta {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-bottom: 16px;
    }

    .material-pill {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        max-width: 100%;
        padding: 8px 13px;
        border: 1px solid var(--border);
        border-radius: 999px;
        background: rgba(255, 255, 255, 0.04);
        color: var(--text-main);
        font-size: 0.8rem;
        font-weight: 700;
        overflow-wrap: anywhere;
    }

    .material-pill-topic {
        border-color: var(--glow);
        color: var(--secondary);
    }

    .material-title {
        max-width: 900px;
        margin: 0 0 12px;
        color: var(--text-main);
        font-family: var(--font-display);
        font-size: clamp(1.8rem, 4vw, 2.7rem);
        font-weight: 800;
        line-height: 1.15;
        overflow-wrap: anywhere;
    }

    .material-description {
        max-width: 760px;
        margin: 0;
        color: var(--text-muted);
        font-size: 1rem;
        line-height: 1.75;
        overflow-wrap: anywhere;
    }

    .material-layout {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 310px;
        align-items: start;
        gap: 22px;
    }

    .material-panel {
        min-width: 0;
        padding: clamp(22px, 4vw, 36px);
    }

    .material-feedback {
        margin: 0 0 18px;
        padding: 14px 17px;
        border: 1px solid rgba(34, 197, 94, 0.35);
        border-radius: 14px;
        background: rgba(34, 197, 94, 0.1);
        color: var(--text-main);
        font-weight: 700;
    }

    .material-feedback-error {
        border-color: rgba(248, 113, 113, 0.4);
        background: rgba(248, 113, 113, 0.1);
    }

    .material-quiz {
        margin-top: 22px;
    }

    .material-quiz-question {
        margin: 0 0 20px;
        padding: 18px;
        border: 1px solid var(--border);
        border-radius: 16px;
        background: rgba(255, 255, 255, 0.025);
    }

    .material-quiz-question legend {
        float: none;
        width: auto;
        margin-bottom: 12px;
        color: var(--text-main);
        font-size: 1rem;
        font-weight: 800;
    }

    .material-quiz-option {
        display: flex;
        align-items: flex-start;
        gap: 10px;
        padding: 10px 12px;
        border-radius: 10px;
        color: var(--text-muted);
        cursor: pointer;
    }

    .material-quiz-option:hover {
        background: rgba(255, 255, 255, 0.045);
        color: var(--text-main);
    }

    .material-quiz-option input {
        margin-top: 5px;
        accent-color: var(--secondary);
    }

    .material-quiz-result {
        margin-bottom: 18px;
        padding: 14px 17px;
        border: 1px solid var(--border);
        border-radius: 14px;
        background: rgba(255, 255, 255, 0.04);
        color: var(--text-main);
        font-weight: 700;
    }

    .material-quiz-result-passed {
        border-color: rgba(34, 197, 94, 0.4);
        background: rgba(34, 197, 94, 0.1);
    }

    .material-section-heading {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 22px;
    }

    .material-section-icon {
        display: inline-flex;
        width: 44px;
        height: 44px;
        flex: 0 0 44px;
        align-items: center;
        justify-content: center;
        border-radius: 14px;
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        color: #fff;
        font-size: 1.15rem;
        box-shadow: 0 6px 18px var(--glow);
    }

    .material-section-heading h2 {
        margin: 0;
        color: var(--text-main);
        font-family: var(--font-display);
        font-size: 1.2rem;
        font-weight: 800;
    }

    .material-section-heading p {
        margin: 3px 0 0;
        color: var(--text-muted);
        font-size: 0.82rem;
    }

    .material-reading {
        color: var(--text-main);
        font-size: 1.04rem;
        line-height: 1.95;
        overflow-wrap: anywhere;
        white-space: pre-line;
    }

    .material-reading::selection {
        background: var(--primary);
        color: #fff;
    }

    .material-sidebar {
        display: grid;
        gap: 18px;
    }

    .material-sidebar h2 {
        margin: 0 0 16px;
        color: var(--text-main);
        font-family: var(--font-display);
        font-size: 1.04rem;
        font-weight: 800;
    }

    .material-topic-name {
        margin-bottom: 8px;
        color: var(--secondary);
        font-size: 1rem;
        font-weight: 800;
        overflow-wrap: anywhere;
    }

    .material-topic-description,
    .material-helper-text {
        margin: 0;
        color: var(--text-muted);
        font-size: 0.85rem;
        line-height: 1.65;
        overflow-wrap: anywhere;
    }

    .material-difficulty {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .material-difficulty-icon {
        display: inline-flex;
        width: 42px;
        height: 42px;
        flex: 0 0 42px;
        align-items: center;
        justify-content: center;
        border-radius: 13px;
        background: rgba(255, 255, 255, 0.06);
        color: var(--secondary);
        font-size: 1.1rem;
    }

    .material-difficulty-label {
        margin-bottom: 3px;
        color: var(--text-muted);
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 0.06em;
        text-transform: uppercase;
    }

    .material-difficulty-value {
        color: var(--text-main);
        font-weight: 800;
    }

    .material-completion-icon {
        display: inline-flex;
        width: 48px;
        height: 48px;
        align-items: center;
        justify-content: center;
        margin-bottom: 14px;
        border-radius: 16px;
        background: rgba(34, 197, 94, 0.14);
        color: #4ade80;
        font-size: 1.35rem;
    }

    .material-completion-title {
        margin: 0 0 8px;
        color: var(--text-main);
        font-family: var(--font-display);
        font-size: 1.05rem;
        font-weight: 800;
    }

    .material-complete-button {
        width: 100%;
        margin-top: 18px;
        padding: 12px 16px;
        border: 0;
        border-radius: 12px;
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        color: #fff;
        font-weight: 800;
        box-shadow: 0 6px 18px var(--glow);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .material-complete-button:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 24px var(--glow);
    }

    .material-complete-button:focus-visible {
        outline: 3px solid var(--text-main);
        outline-offset: 3px;
    }

    @media (max-width: 991px) {
        .material-layout {
            grid-template-columns: minmax(0, 1fr) 270px;
        }
    }

    @media (max-width: 767px) {
        .material-page {
            padding: 18px 14px 40px;
        }

        .material-layout {
            grid-template-columns: 1fr;
        }

        .material-sidebar {
            grid-row: auto;
        }

        .material-hero-image {
            max-height: 240px;
        }
    }

    @media (prefers-reduced-motion: reduce) {
        .material-back-link,
        .material-complete-button {
            transition: none;
        }

        .material-complete-button:hover {
            transform: none;
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="material-page">
    <a href="<?php echo e(route('student.learning-materials.index')); ?>" class="material-back-link">
        <i class="bi bi-arrow-left" aria-hidden="true"></i>
        <span>All learning materials</span>
    </a>

    <?php if(session('success')): ?>
        <div class="material-feedback" role="status" aria-live="polite">
            <i class="bi bi-check-circle-fill me-2" aria-hidden="true"></i>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('info')): ?>
        <div class="material-feedback" role="status" aria-live="polite">
            <i class="bi bi-info-circle-fill me-2" aria-hidden="true"></i>
            <?php echo e(session('info')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="material-feedback material-feedback-error" role="alert">
            <i class="bi bi-exclamation-circle-fill me-2" aria-hidden="true"></i>
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="material-feedback material-feedback-error" role="alert">
            Please answer every quiz question before submitting.
        </div>
    <?php endif; ?>

    <header class="material-hero">
        <?php if($learningMaterial->image): ?>
            <img
                src="<?php echo e(asset('storage/' . $learningMaterial->image)); ?>"
                alt="<?php echo e($learningMaterial->title); ?>"
                class="material-hero-image"
            >
        <?php endif; ?>

        <div class="material-hero-copy">
            <div class="material-eyebrow">
                <i class="bi bi-book-half" aria-hidden="true"></i>
                <span>Learning material</span>
            </div>

            <div class="material-meta" aria-label="Material details">
                <span class="material-pill material-pill-topic">
                    <i class="bi bi-bookmark-fill" aria-hidden="true"></i>
                    <?php echo e($learningMaterial->topic); ?>

                </span>
                <span class="material-pill">
                    <i class="bi bi-layers-fill" aria-hidden="true"></i>
                    Level <?php echo e($levelNumber); ?>

                </span>
                <span class="material-pill">
                    <i class="bi bi-bar-chart-fill" aria-hidden="true"></i>
                    <?php echo e(ucfirst($learningMaterial->difficulty)); ?> level
                </span>
            </div>

            <h1 class="material-title"><?php echo e($learningMaterial->title); ?></h1>

            <?php if($learningMaterial->description): ?>
                <p class="material-description"><?php echo e($learningMaterial->description); ?></p>
            <?php else: ?>
                <p class="material-description">
                    Read through this lesson at your own pace, then mark it complete when you’re ready.
                </p>
            <?php endif; ?>
        </div>
    </header>

    <div class="material-layout">
        <article class="material-panel" aria-labelledby="material-content-heading">
            <div class="material-section-heading">
                <span class="material-section-icon" aria-hidden="true">
                    <i class="bi bi-journal-text"></i>
                </span>
                <div>
                    <h2 id="material-content-heading">Lesson</h2>
                    <p>Take your time and work through the ideas below.</p>
                </div>
            </div>

            <div class="material-reading"><?php echo e($learningMaterial->content); ?></div>
        </article>

        <aside class="material-sidebar" aria-label="Lesson information and progress">
            <section class="material-panel">
                <h2>About this topic</h2>
                <div class="material-topic-name"><?php echo e($learningMaterial->topic); ?></div>

                <?php if($topic && $topic->description): ?>
                    <p class="material-topic-description"><?php echo e($topic->description); ?></p>
                <?php else: ?>
                    <p class="material-topic-description">
                        Explore this lesson to build your understanding of <?php echo e($learningMaterial->topic); ?>.
                    </p>
                <?php endif; ?>
            </section>

            <section class="material-panel">
                <h2>Your progress</h2>

                <?php if($progress->completed_at): ?>
                    <div class="material-completion-icon" aria-hidden="true">
                        <i class="bi bi-check-lg"></i>
                    </div>
                    <p class="material-completion-title">Lesson completed</p>
                    <p class="material-helper-text">
                        Completed <?php echo e($progress->completed_at->format('M j, Y \a\t g:i A')); ?>.
                        You can revisit the lesson whenever you need a refresher.
                    </p>
                <?php else: ?>
                    <p class="material-helper-text">
                        Read the lesson, then complete it to reveal the quiz. Pass with at least 70% to unlock the next level.
                    </p>

                    <form method="POST" action="<?php echo e(route('student.learning-materials.complete', $learningMaterial)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="material-complete-button">
                            <i class="bi bi-check2-circle me-2" aria-hidden="true"></i>
                            Mark as completed
                        </button>
                    </form>
                <?php endif; ?>
            </section>

            <div class="material-panel">
                <div class="material-difficulty">
                    <span class="material-difficulty-icon" aria-hidden="true">
                        <i class="bi bi-speedometer2"></i>
                    </span>
                    <div>
                        <div class="material-difficulty-label">Difficulty</div>
                        <div class="material-difficulty-value"><?php echo e(ucfirst($learningMaterial->difficulty)); ?></div>
                    </div>
                </div>
            </div>
        </aside>
    </div>

    <?php if($progress->completed_at): ?>
        <section class="material-panel material-quiz" aria-labelledby="lesson-quiz-heading">
            <div class="material-section-heading">
                <span class="material-section-icon" aria-hidden="true">
                    <i class="bi bi-patch-question-fill"></i>
                </span>
                <div>
                    <h2 id="lesson-quiz-heading">Lesson Quiz</h2>
                    <p>Answer at least 70% correctly to unlock the next level. You can retry if needed.</p>
                </div>
            </div>

            <?php if(session('quiz_result')): ?>
                <div class="material-quiz-result <?php echo e(session('quiz_result.passed') ? 'material-quiz-result-passed' : ''); ?>"
                    role="status" aria-live="polite">
                    <?php if(session('quiz_result.passed')): ?>
                        Quiz passed! You scored <?php echo e(session('quiz_result.score')); ?>% (<?php echo e(session('quiz_result.correct')); ?>/<?php echo e(session('quiz_result.total')); ?>). The next level is unlocked.
                    <?php else: ?>
                        You scored <?php echo e(session('quiz_result.score')); ?>% (<?php echo e(session('quiz_result.correct')); ?>/<?php echo e(session('quiz_result.total')); ?>). Review the lesson and try again; 70% is required.
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if($progress->quiz_data && is_array($progress->quiz_data['questions'] ?? null)): ?>
                <?php if($progress->quiz_completed_at): ?>
                    <p class="material-helper-text mb-3">
                        Quiz passed with <?php echo e($progress->quiz_score); ?>%. You may revisit this lesson; your next level remains unlocked.
                    </p>
                    <?php if($nextLearningMaterial): ?>
                        <a href="<?php echo e(route('student.learning-materials.show', $nextLearningMaterial)); ?>"
                            class="material-complete-button d-inline-flex align-items-center justify-content-center text-decoration-none">
                            Continue to Level <?php echo e($levelNumber + 1); ?>

                            <i class="bi bi-arrow-right ms-2" aria-hidden="true"></i>
                        </a>
                    <?php else: ?>
                        <p class="material-helper-text mb-0">You completed the final published lesson in this topic.</p>
                    <?php endif; ?>
                <?php else: ?>
                    <form method="POST" action="<?php echo e(route('student.learning-materials.quiz.submit', $learningMaterial)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php $__currentLoopData = $progress->quiz_data['questions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questionIndex => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <fieldset class="material-quiz-question">
                                <legend><?php echo e($questionIndex + 1); ?>. <?php echo e($question['question']); ?></legend>
                                <?php $__currentLoopData = $question['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="material-quiz-option">
                                        <input
                                            type="radio"
                                            name="answers[<?php echo e($questionIndex); ?>]"
                                            value="<?php echo e($option); ?>"
                                            required
                                            <?php echo e(old("answers.{$questionIndex}") === $option ? 'checked' : ''); ?>

                                        >
                                        <span><?php echo e($option); ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </fieldset>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button type="submit" class="material-complete-button">
                            <i class="bi bi-check2-circle me-2" aria-hidden="true"></i>
                            Submit quiz
                        </button>
                    </form>
                <?php endif; ?>
            <?php else: ?>
                <p class="material-helper-text">
                    Your lesson is complete, but its quiz is not ready yet. Generate it from this lesson content to continue.
                </p>
                <form method="POST" action="<?php echo e(route('student.learning-materials.quiz.generate', $learningMaterial)); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="material-complete-button">
                        <i class="bi bi-arrow-repeat me-2" aria-hidden="true"></i>
                        Generate quiz
                    </button>
                </form>
            <?php endif; ?>
        </section>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gamified-education\resources\views/student/learning-materials/show.blade.php ENDPATH**/ ?>