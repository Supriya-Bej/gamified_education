

<?php $__env->startSection('title', 'Leaderboard | EcoQuest'); ?>

<?php $__env->startSection('content'); ?>
<section class="theme-page">
    <div class="container-fluid py-4">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
            <div>
                <h1 class="h2 fw-bold mb-1" style="color:var(--secondary);">Leaderboard</h1>
                <p class="mb-0" style="color:var(--text-muted);">Students ranked by total XP earned.</p>
            </div>
            <div class="rounded-3 px-4 py-3" style="background:var(--surface); border:1px solid var(--border);">
                <span style="color:var(--text-muted);">Your rank</span>
                <strong class="ms-2" style="color:var(--secondary);">
                    #<?php echo e(number_format($userRank ?? 0)); ?>

                </strong>
            </div>
        </div>

        <div class="rounded-4 overflow-hidden" style="background:var(--surface); border:1px solid var(--border);">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr style="color:var(--text-muted); border-color:var(--border);">
                            <th scope="col" class="px-4 py-3">Rank</th>
                            <th scope="col" class="py-3">Student</th>
                            <th scope="col" class="px-4 py-3 text-end">Total XP</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leaderboardStudent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr style="color:var(--text-main); border-color:var(--border);">
                                <th scope="row" class="px-4">
                                    #<?php echo e(number_format($leaderboardStudent->leaderboard_rank)); ?>

                                </th>
                                <td>
                                    <?php echo e($leaderboardStudent->name); ?>

                                    <?php if((int) $leaderboardStudent->id === (int) auth('student')->id()): ?>
                                        <span class="badge rounded-pill ms-2" style="background:var(--primary);">You</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 text-end fw-bold" style="color:var(--secondary);">
                                    <?php echo e(number_format($leaderboardStudent->total_xp)); ?> XP
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3" class="text-center py-5" style="color:var(--text-muted);">
                                    No students are on the leaderboard yet.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($students->hasPages()): ?>
                <div class="p-3" style="border-top:1px solid var(--border);">
                    <?php echo e($students->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gamified-education\resources\views/student/leaderboard/index.blade.php ENDPATH**/ ?>