<?php ($questions = data_get($task->game_data, 'questions', [])); ?>
<?php echo $__env->make('student.games.partials.multiple-choice-quiz', [
    'gameLabel' => strtoupper(str_replace('_', ' ', $task->category)).' QUEST',
    'gameIcon' => '🧠',
    'accentColor' => '#38bdf8',
    'supportingCopy' => $game->description ?? 'Answer the questions to complete this learning quest.',
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\xampp\htdocs\gamified-education\resources\views/student/games/knowledge-quiz.blade.php ENDPATH**/ ?>