


<?php $__env->startSection('title', 'Task Details'); ?>
<?php $__env->startSection('page-heading', 'Learning Task Details'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid py-3">

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm rounded-3">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm rounded-3">
            <i class="bi bi-exclamation-circle-fill me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    
    <div class="mb-4">
        <a href="<?php echo e(route('admin.tasks.index')); ?>"
           class="btn btn-white border shadow-sm rounded-3 px-3">
            <i class="bi bi-arrow-left me-2"></i>
            Back to Tasks
        </a>
    </div>

    
    <div class="task-detail-hero rounded-4 p-4 p-lg-5 mb-4 text-white">
        <div class="row align-items-center g-3">
            <div class="col-lg-8">
                <div class="d-flex align-items-start gap-3">
                    <div class="hero-icon">
                        <i class="bi bi-journal-check"></i>
                    </div>

                    <div class="min-w-0">
                        <span class="small text-white-50 text-uppercase fw-semibold">
                            EcoQuest Administration
                        </span>

                        <h2 class="fw-bold mt-2 mb-2">
                            <?php echo e($task->title); ?>

                        </h2>

                        <p class="text-white-50 mb-2">
                            Review the game quest and manage its approval.
                        </p>

                        <small class="text-white-50">
                            <i class="bi bi-calendar3 me-1"></i>
                            Created <?php echo e($task->created_at?->format('d M Y, h:i A') ?? 'N/A'); ?>

                        </small>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 text-lg-end">
                <?php
                    $reviewStatus = $task->review_status ?? 'pending_review';

                    $reviewClass = match($reviewStatus) {
                        'approved' => 'review-approved',
                        'rejected' => 'review-rejected',
                        default => 'review-pending'
                    };

                    $statusClass = $task->status === 'completed'
                        ? 'task-completed'
                        : 'task-pending';
                ?>

                <div class="d-flex flex-wrap gap-2 justify-content-lg-end">
                    <span class="detail-status <?php echo e($reviewClass); ?>">
                        <i class="bi bi-shield-check me-1"></i>
                        <?php echo e(ucwords(str_replace('_', ' ', $reviewStatus))); ?>

                    </span>

                    <span class="detail-status <?php echo e($statusClass); ?>">
                        <i class="bi <?php echo e($task->status === 'completed' ? 'bi-check-circle-fill' : 'bi-hourglass-split'); ?> me-1"></i>
                        <?php echo e(ucfirst($task->status ?? 'Pending')); ?>

                    </span>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">

        
        <div class="col-xl-8">

            
            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-header bg-white border-0 p-4 pb-0">
                    <h5 class="fw-bold mb-1">
                        <i class="bi bi-file-earmark-text text-primary me-2"></i>
                        Game Quest Overview
                    </h5>
                    <p class="text-muted small mb-0">
                        Details and learning requirements for this task.
                    </p>
                </div>

                <div class="card-body p-4">
                    <div class="description-panel mb-4">
                        <h6 class="fw-bold mb-3">Task Description</h6>
                        <p class="text-secondary mb-0 description-text"><?php echo e($task->description ?? 'No description available.'); ?></p>
                    </div>

                    <div class="row g-3">

                        <div class="col-sm-6">
                            <div class="detail-info-card">
                                <div class="detail-info-icon icon-purple">
                                    <i class="bi bi-folder2-open"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block mb-1">Category</small>
                                    <span class="fw-semibold"><?php echo e($task->category ?? 'N/A'); ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="detail-info-card">
                                <div class="detail-info-icon icon-orange">
                                    <i class="bi bi-speedometer2"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block mb-1">Difficulty</small>
                                    <span class="fw-semibold">
                                        <?php echo e(ucfirst($task->difficulty ?? 'N/A')); ?>

                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="detail-info-card">
                                <div class="detail-info-icon icon-blue">
                                    <i class="bi bi-controller"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block mb-1">Game Type</small>
                                    <code><?php echo e($task->game_type ?? 'N/A'); ?></code>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="detail-info-card">
                                <div class="detail-info-icon icon-green">
                                    <i class="bi bi-lightning-charge-fill"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block mb-1">XP Reward</small>
                                    <span class="fw-bold text-primary">
                                        <?php echo e($task->xp ?? 0); ?> XP
                                    </span>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            
            <?php if(in_array($task->review_status, ['pending_review', 'rejected'], true)): ?>

                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-header bg-white border-0 p-4 pb-0">
                        <div class="d-flex align-items-start gap-3">
                            <div class="section-icon">
                                <i class="bi bi-pencil-square"></i>
                            </div>
                            <div>
                                <h5 class="fw-bold mb-1">Review & Edit Game Quest</h5>
                                <p class="text-muted small mb-0">
                                    Update the game quest before approving it.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="card-body p-4">

                        <form method="POST"
                              action="<?php echo e(route('admin.tasks.review', $task)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            
                            <div class="mb-4">
                                <label for="title" class="form-label fw-semibold">
                                    Quest Title
                                </label>
                                <input
                                    id="title"
                                    name="title"
                                    class="form-control form-control-lg <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('title', $task->title)); ?>"
                                    required
                                    maxlength="255"
                                >
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="mb-4">
                                <label for="description" class="form-label fw-semibold">
                                    Description
                                </label>
                                <textarea
                                    id="description"
                                    name="description"
                                    rows="4"
                                    class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    required
                                    maxlength="2000"
                                ><?php echo e(old('description', $task->description)); ?></textarea>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="row g-3 mb-4">
                                <div class="col-md-6">
                                    <label for="difficulty" class="form-label fw-semibold">
                                        <i class="bi bi-bar-chart me-1 text-primary"></i>
                                        Difficulty
                                    </label>

                                    <select
                                        id="difficulty"
                                        name="difficulty"
                                        class="form-select <?php $__errorArgs = ['difficulty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        required
                                    >
                                        <?php $__currentLoopData = ['beginner', 'intermediate', 'advanced']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $difficulty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                                value="<?php echo e($difficulty); ?>"
                                                <?php if(old('difficulty', $task->difficulty) === $difficulty): echo 'selected'; endif; ?>
                                            >
                                                <?php echo e(ucfirst($difficulty)); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php $__errorArgs = ['difficulty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-6">
                                    <label for="xp" class="form-label fw-semibold">
                                        <i class="bi bi-lightning-charge me-1 text-warning"></i>
                                        XP Reward
                                    </label>

                                    <div class="input-group">
                                        <input
                                            id="xp"
                                            type="number"
                                            name="xp"
                                            min="10"
                                            max="50"
                                            class="form-control <?php $__errorArgs = ['xp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('xp', $task->xp)); ?>"
                                            required
                                        >
                                        <span class="input-group-text">XP</span>
                                        <?php $__errorArgs = ['xp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-text">Allowed reward: 10–50 XP.</div>
                                </div>
                            </div>

                            
                            <div class="mb-4">
                                <label for="game_data" class="form-label fw-semibold">
                                    <i class="bi bi-braces me-1 text-primary"></i>
                                    Game Data (JSON)
                                </label>

                                <textarea
                                    id="game_data"
                                    name="game_data"
                                    rows="10"
                                    class="form-control font-monospace json-editor <?php $__errorArgs = ['game_data'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    required
                                ><?php echo e(old('game_data', json_encode($task->game_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES))); ?></textarea>

                                <div class="form-text">
                                    Ensure this JSON matches the selected game type and passes validation.
                                </div>

                                <?php $__errorArgs = ['game_data'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="mb-4">
                                <label for="review_note" class="form-label fw-semibold">
                                    Review Note <span class="text-muted fw-normal">(Optional)</span>
                                </label>

                                <textarea
                                    id="review_note"
                                    name="review_note"
                                    rows="3"
                                    maxlength="1000"
                                    class="form-control"
                                    placeholder="Add feedback or explain any changes..."
                                ><?php echo e(old('review_note', $task->review_note)); ?></textarea>
                            </div>

                            <div class="review-actions d-flex flex-wrap gap-2">
                                <button
                                    class="btn btn-outline-primary rounded-3 px-4"
                                    type="submit"
                                    name="decision"
                                    value="save"
                                >
                                    <i class="bi bi-save me-2"></i>
                                    Save Edits
                                </button>

                                <button
                                    class="btn btn-success rounded-3 px-4"
                                    type="submit"
                                    name="decision"
                                    value="approve"
                                >
                                    <i class="bi bi-check-circle-fill me-2"></i>
                                    Approve Game Quest
                                </button>
                            </div>
                        </form>

                        
                        <div class="rejection-panel mt-4">
                            <h6 class="fw-bold text-danger mb-2">
                                <i class="bi bi-x-circle me-2"></i>
                                Reject Game Quest
                            </h6>
                            <p class="text-muted small">
                                Provide a reason for rejecting this game quest.
                            </p>

                            <form
                                method="POST"
                                action="<?php echo e(route('admin.tasks.reject', $task)); ?>"
                            >
                                <?php echo csrf_field(); ?>

                                <label for="reject-note" class="form-label fw-semibold">
                                    Reason for Rejection
                                </label>

                                <textarea
                                    id="reject-note"
                                    name="review_note"
                                    rows="3"
                                    maxlength="1000"
                                    class="form-control <?php $__errorArgs = ['review_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Explain why this game quest should be rejected..."
                                    required
                                ><?php echo e(old('review_note')); ?></textarea>

                                <?php $__errorArgs = ['review_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <button class="btn btn-outline-danger rounded-3 mt-3 px-4" type="submit">
                                    <i class="bi bi-x-circle me-2"></i>
                                    Reject Game Quest
                                </button>
                            </form>
                        </div>

                    </div>
                </div>

            <?php elseif($task->review_note): ?>

                
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3">
                            <i class="bi bi-chat-left-text text-primary me-2"></i>
                            Review Feedback
                        </h5>

                        <div class="review-note-box">
                            <?php echo e($task->review_note); ?>

                        </div>

                        <?php if($task->reviewer): ?>
                            <div class="small text-muted mt-3">
                                <i class="bi bi-person-check me-1"></i>
                                <?php echo e($task->review_status === 'approved' ? 'Approved' : 'Reviewed'); ?>

                                by <strong><?php echo e($task->reviewer->name); ?></strong>

                                <?php if($task->reviewed_at): ?>
                                    on <?php echo e($task->reviewed_at->format('d M Y, h:i A')); ?>

                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            <?php endif; ?>

        </div>

        
        <div class="col-xl-4">

            
            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-header bg-white border-0 p-4 pb-0">
                    <h5 class="fw-bold mb-0">
                        <i class="bi bi-people text-primary me-2"></i>
                        Assigned Student
                    </h5>
                </div>

                <div class="card-body p-4">
                    <?php if($task->user): ?>
                        <div class="student-profile mb-3">
                            <div class="student-avatar">
                                <?php echo e(strtoupper(substr($task->user->name, 0, 1))); ?>

                            </div>

                            <div class="min-w-0">
                                <h6 class="fw-bold mb-1 text-break">
                                    <?php echo e($task->user->name); ?>

                                </h6>
                                <span class="badge bg-primary-subtle text-primary">
                                    Student
                                </span>
                            </div>
                        </div>

                        <div class="sidebar-info">
                            <i class="bi bi-envelope"></i>
                            <span class="text-break"><?php echo e($task->user->email); ?></span>
                        </div>
                    <?php else: ?>
                        <div class="empty-sidebar text-center py-3">
                            <i class="bi bi-person-x fs-2 text-muted"></i>
                            <p class="text-muted small mb-0 mt-2">
                                This student no longer exists.
                            </p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-header bg-white border-0 p-4 pb-0">
                    <h5 class="fw-bold mb-0">
                        <i class="bi bi-controller text-primary me-2"></i>
                        Connected Game
                    </h5>
                </div>

                <div class="card-body p-4">
                    <?php if($task->game): ?>
                        <div class="game-banner mb-3">
                            <i class="bi bi-joystick"></i>
                        </div>

                        <h6 class="fw-bold mb-2">
                            <?php echo e($task->game->name); ?>

                        </h6>

                        <p class="text-muted small mb-3">
                            <?php echo e($task->game->description ?? 'No game description available.'); ?>

                        </p>

                        <div class="game-meta">
                            <small class="text-muted d-block mb-1">Game Type</small>
                            <span class="badge bg-dark rounded-pill px-3 py-2">
                                <?php echo e($task->game->game_type ?? 'N/A'); ?>

                            </span>
                        </div>
                    <?php else: ?>
                        <div class="empty-sidebar text-center py-3">
                            <i class="bi bi-controller fs-2 text-muted"></i>
                            <p class="text-muted small mb-0 mt-2">
                                No game is connected to this task.
                            </p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body p-4">
                    <h6 class="fw-bold mb-3">
                        <i class="bi bi-info-circle text-primary me-2"></i>
                        Quick Summary
                    </h6>

                    <div class="summary-row">
                        <span class="text-muted">Task ID</span>
                        <strong>#<?php echo e($task->id); ?></strong>
                    </div>

                    <div class="summary-row">
                        <span class="text-muted">Category</span>
                        <strong><?php echo e($task->category ?? 'N/A'); ?></strong>
                    </div>

                    <div class="summary-row">
                        <span class="text-muted">Reward</span>
                        <strong class="text-primary"><?php echo e($task->xp ?? 0); ?> XP</strong>
                    </div>

                    <div class="summary-row">
                        <span class="text-muted">Created</span>
                        <strong><?php echo e($task->created_at?->format('d M Y') ?? 'N/A'); ?></strong>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>

<style>
    .task-detail-hero {
        background: linear-gradient(120deg, #173b8f, #315bd6 58%, #667eea);
        box-shadow: 0 12px 30px rgba(49, 91, 214, .16);
    }

    .hero-icon {
        width: 62px;
        height: 62px;
        flex-shrink: 0;
        display: grid;
        place-items: center;
        border-radius: 18px;
        background: rgba(255, 255, 255, .16);
        font-size: 1.8rem;
    }

    .detail-status {
        display: inline-flex;
        align-items: center;
        padding: 9px 13px;
        border-radius: 50px;
        font-size: .78rem;
        font-weight: 700;
        white-space: nowrap;
    }

    .review-approved, .task-completed {
        color: #166534;
        background: #dcfce7;
    }

    .review-rejected {
        color: #991b1b;
        background: #fee2e2;
    }

    .review-pending, .task-pending {
        color: #92400e;
        background: #fef3c7;
    }

    .description-panel {
        padding: 20px;
        border: 1px solid #edf0f5;
        border-radius: 14px;
        background: #fafbfe;
    }

    .description-text {
        line-height: 1.8;
        white-space: pre-line;
        overflow-wrap: anywhere;
    }

    .detail-info-card {
        display: flex;
        align-items: center;
        gap: 13px;
        height: 100%;
        padding: 16px;
        border: 1px solid #edf0f5;
        border-radius: 14px;
        background: #fff;
    }

    .detail-info-icon {
        width: 44px;
        height: 44px;
        flex-shrink: 0;
        display: grid;
        place-items: center;
        border-radius: 12px;
        font-size: 1.2rem;
    }

    .icon-purple {
        color: #7c3aed;
        background: #f3e8ff;
    }

    .icon-orange {
        color: #c2410c;
        background: #ffedd5;
    }

    .icon-blue {
        color: #1d4ed8;
        background: #dbeafe;
    }

    .icon-green {
        color: #15803d;
        background: #dcfce7;
    }

    .section-icon {
        width: 44px;
        height: 44px;
        flex-shrink: 0;
        display: grid;
        place-items: center;
        border-radius: 12px;
        color: #315bd6;
        background: #edf2ff;
        font-size: 1.25rem;
    }

    .form-control, .form-select, .input-group-text {
        border-color: #e2e8f0;
        border-radius: 10px;
    }

    .form-control, .form-select {
        padding: 11px 13px;
    }

    .input-group .form-control {
        border-radius: 10px 0 0 10px;
    }

    .input-group .input-group-text {
        border-radius: 0 10px 10px 0;
        background: #f8fafc;
    }

    .form-control:focus, .form-select:focus {
        border-color: #829cff;
        box-shadow: 0 0 0 .2rem rgba(49, 91, 214, .10);
    }

    .json-editor {
        background: #f8fafc;
        font-size: .85rem;
        line-height: 1.7;
        tab-size: 4;
    }

    .rejection-panel {
        padding: 20px;
        border: 1px solid #fee2e2;
        border-radius: 14px;
        background: #fffafa;
    }

    .review-note-box {
        padding: 16px;
        border-radius: 12px;
        background: #f8fafc;
        border: 1px solid #edf0f5;
        color: #475467;
        line-height: 1.7;
        white-space: pre-line;
        overflow-wrap: anywhere;
    }

    .student-profile {
        display: flex;
        align-items: center;
        gap: 14px;
    }

    .student-avatar {
        width: 52px;
        height: 52px;
        flex-shrink: 0;
        display: grid;
        place-items: center;
        border-radius: 16px;
        background: linear-gradient(135deg, #315bd6, #667eea);
        color: #fff;
        font-size: 1.35rem;
        font-weight: 700;
    }

    .sidebar-info {
        display: flex;
        align-items: flex-start;
        gap: 10px;
        padding-top: 15px;
        border-top: 1px solid #edf0f5;
        color: #667085;
        font-size: .875rem;
    }

    .sidebar-info i {
        color: #315bd6;
        margin-top: 3px;
    }

    .game-banner {
        height: 110px;
        display: grid;
        place-items: center;
        border-radius: 14px;
        background: linear-gradient(135deg, #edf2ff, #e0e7ff);
        color: #315bd6;
        font-size: 2.7rem;
    }

    .summary-row {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 12px;
        padding: 12px 0;
        border-bottom: 1px solid #edf0f5;
        font-size: .875rem;
    }

    .summary-row:last-child {
        padding-bottom: 0;
        border-bottom: 0;
    }

    .summary-row strong {
        text-align: right;
        overflow-wrap: anywhere;
    }

    .card {
        transition: box-shadow .2s ease;
    }

    .btn {
        transition: all .2s ease;
    }

    .btn:hover {
        transform: translateY(-1px);
    }

    @media (max-width: 575.98px) {
        .hero-icon {
            width: 48px;
            height: 48px;
            border-radius: 14px;
            font-size: 1.4rem;
        }

        .task-detail-hero {
            padding: 1.25rem !important;
        }

        .review-actions .btn {
            width: 100%;
        }
    }
</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gamified-education\resources\views/admin/tasks/show.blade.php ENDPATH**/ ?>