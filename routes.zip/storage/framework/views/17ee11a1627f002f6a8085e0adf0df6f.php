

<?php $__env->startSection('title', 'Learning Materials | EcoQuest'); ?>

<?php $__env->startSection('head'); ?>
<style>
    .materials-pagination {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        gap: 18px;
        margin-top: 30px;
        padding: 18px 20px;
        border: 1px solid var(--border);
        border-radius: 18px;
        background: linear-gradient(145deg, var(--surface), var(--surface-alt));
    }

    .materials-pagination-summary {
        color: var(--text-muted);
        font-size: 0.86rem;
        line-height: 1.5;
    }

    .materials-pagination-summary strong {
        color: var(--text-main);
        font-weight: 800;
    }

    .materials-pagination .pagination {
        flex-wrap: wrap;
        gap: 6px;
        margin-bottom: 0;
    }

    .materials-pagination .page-link {
        min-width: 40px;
        min-height: 40px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-color: var(--border);
        border-radius: 12px !important;
        background: rgba(255, 255, 255, 0.035);
        color: var(--text-muted);
        font-size: 0.84rem;
        font-weight: 800;
        transition: border-color 0.18s ease, background-color 0.18s ease, color 0.18s ease, transform 0.18s ease;
    }

    .materials-pagination .page-link:hover {
        transform: translateY(-1px);
        border-color: var(--secondary);
        background: rgba(255, 255, 255, 0.08);
        color: var(--text-main);
    }

    .materials-pagination .page-link:focus-visible {
        outline: 3px solid var(--secondary);
        outline-offset: 3px;
        box-shadow: none;
    }

    .materials-pagination .page-item.active .page-link {
        border-color: transparent;
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        color: #fff;
        box-shadow: 0 5px 16px var(--glow);
    }

    .materials-pagination .page-item.disabled .page-link {
        background: rgba(255, 255, 255, 0.02);
        color: var(--text-muted);
        opacity: 0.55;
    }

    @media (max-width: 767px) {
        .materials-pagination {
            align-items: stretch;
            padding: 16px;
        }

        .materials-pagination > nav {
            width: 100%;
        }

        .materials-pagination .pagination {
            justify-content: center;
        }

        .materials-pagination .page-link {
            min-width: 38px;
            min-height: 38px;
        }
    }

    @media (prefers-reduced-motion: reduce) {
        .materials-pagination .page-link {
            transition: none;
        }

        .materials-pagination .page-link:hover {
            transform: none;
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid py-4">

    
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">

        <div>
            <div class="d-flex align-items-center gap-2 mb-2">
                <span class="badge bg-primary-subtle text-primary px-3 py-2">
                    <i class="bi bi-book-half me-1"></i>
                    LEARN
                </span>
            </div>

            <h2 class="fw-bold mb-1">
                Learning Materials
            </h2>

            <p class="text-muted mb-0">
                Explore topics, learn something new, and grow your knowledge.
            </p>
        </div>

        <div class="text-end">
            <div class="small text-muted">
                Welcome back
            </div>

            <div class="fw-semibold">
                <?php echo e($student->name); ?>

            </div>
        </div>

    </div>

    

    
    <div class="mb-4">

        <h5 class="fw-bold mb-3">
            <i class="bi bi-grid-fill me-2 text-primary"></i>
            Explore Topics
        </h5>

        <div class="d-flex flex-wrap gap-2">

            
            <a href="<?php echo e(route('student.learning-materials.index')); ?>"
                class="btn <?php echo e(!request('topic') ? 'btn-primary' : 'btn-outline-secondary'); ?> rounded-pill px-4">

                <i class="bi bi-stars me-1"></i>
                All Topics

            </a>


            
            <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <a href="<?php echo e(route(
                    'student.learning-materials.index',
                    ['topic' => $topic->id]
                )); ?>"
                class="btn <?php echo e(request('topic') == $topic->id
                    ? 'btn-primary'
                    : 'btn-outline-secondary'); ?>

                    rounded-pill px-4">

                <?php echo e($topic->name); ?>


            </a>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>

    
    <?php if($materials->count() > 0): ?>

    <div class="row g-4">

        <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $isUnlocked = in_array((int) $material->id, $unlockedMaterialIds, true);
            $progress = $materialProgress->get($material->id);
        ?>

        <div class="col-md-6 col-xl-4 material-card"
            data-topic="<?php echo e(strtolower($material->topic)); ?>">

            <div class="card border-0 shadow-sm h-100 overflow-hidden">

                
                <?php if($material->image): ?>

                <img src="<?php echo e(asset('storage/' . $material->image)); ?>"
                    alt="<?php echo e($material->title); ?>"
                    class="w-100"
                    style="height:190px; object-fit:cover;">

                <?php else: ?>

                <div class="d-flex align-items-center justify-content-center bg-primary-subtle"
                    style="height:190px;">

                    <i class="bi bi-book-half text-primary"
                        style="font-size:55px;"></i>

                </div>

                <?php endif; ?>


                <div class="card-body p-4">

                    
                    <div class="d-flex flex-wrap gap-2 mb-3">

                        <span class="badge bg-primary-subtle text-primary">
                            <?php echo e($material->topic); ?>

                        </span>

                        <span class="badge
                                    <?php if($material->difficulty === 'beginner'): ?>
                                        bg-success-subtle text-success
                                    <?php elseif($material->difficulty === 'intermediate'): ?>
                                        bg-warning-subtle text-warning
                                    <?php else: ?>
                                        bg-danger-subtle text-danger
                                    <?php endif; ?>">

                            <?php echo e(ucfirst($material->difficulty)); ?>


                        </span>

                    </div>


                    
                    <h5 class="fw-bold mb-2">
                        <?php echo e($material->title); ?>

                    </h5>


                    
                    <p class="text-muted small mb-4">

                        <?php echo e(\Illuminate\Support\Str::limit(
                                    $material->description,
                                    110
                                )); ?>


                    </p>


                    
                    <?php if($isUnlocked): ?>
                        <a href="<?php echo e(route('student.learning-materials.show', $material)); ?>"
                            class="btn btn-outline-primary w-100">
                            <i class="bi <?php echo e($progress?->completed_at ? 'bi-patch-question' : 'bi-book-open'); ?> me-1"></i>
                            <?php echo e($progress?->completed_at ? 'Continue to quiz' : 'Start Learning'); ?>

                        </a>
                        <?php if($progress?->quiz_completed_at): ?>
                            <div class="small text-success text-center mt-2">
                                <i class="bi bi-check-circle-fill me-1" aria-hidden="true"></i>
                                Quiz passed — level complete
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <button type="button" class="btn btn-outline-secondary w-100" disabled>
                            <i class="bi bi-lock-fill me-1" aria-hidden="true"></i>
                            Locked — pass the previous lesson quiz
                        </button>
                    <?php endif; ?>

                </div>

            </div>

        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>


    
    <div class="materials-pagination">
        <p class="materials-pagination-summary mb-0" role="status" aria-live="polite">
            Showing
            <strong><?php echo e(number_format($materials->firstItem())); ?>–<?php echo e(number_format($materials->lastItem())); ?></strong>
            of
            <strong><?php echo e(number_format($materials->total())); ?></strong>
            <?php echo e(\Illuminate\Support\Str::plural('learning material', $materials->total())); ?>

        </p>

        <?php if($materials->hasPages()): ?>
            <?php echo e($materials->links()); ?>

        <?php endif; ?>
    </div>

    <?php else: ?>

    
    <div class="card border-0 shadow-sm">

        <div class="card-body text-center py-5">

            <div class="mb-3">
                <i class="bi bi-journal-x text-muted"
                    style="font-size:65px;"></i>
            </div>

            <h4 class="fw-bold">
                No Learning Materials Yet
            </h4>

            <p class="text-muted mb-0">
                New learning materials will appear here soon.
            </p>

        </div>

    </div>

    <?php endif; ?>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gamified-education\resources\views/student/learning-materials/index.blade.php ENDPATH**/ ?>