<aside id="studentSidebar" class="sidebar">


    

    <a
        href="<?php echo e(route('student.dashboard')); ?>"
        class="brand">


        <div class="brand-icon">

            <?php echo e($themeIcon ?? '✦'); ?>


        </div>


        <div>

            <div class="brand-title">

                Eco<span>Quest</span>

            </div>


            <div class="brand-subtitle">

                Gamified Learning

            </div>

        </div>


    </a>



    

    <div class="nav-category">

        Main Menu

    </div>


    <a
        href="<?php echo e(route('student.dashboard')); ?>"
        class="side-link
        <?php echo e(request()->routeIs('student.dashboard') ? 'active' : ''); ?>">

        <i class="bi bi-grid-1x2-fill"></i>

        <span>Dashboard</span>

    </a>



    <a
        href="<?php echo e(route('student.profile')); ?>"
        class="side-link
        <?php echo e(request()->routeIs('student.profile') ? 'active' : ''); ?>">

        <i class="bi bi-person-circle"></i>

        <span>My Profile</span>

    </a>



    <a
        href="<?php echo e(route('student.badges')); ?>"
        class="side-link
        <?php echo e(request()->routeIs('student.badges') ? 'active' : ''); ?>">

        <i class="bi bi-award-fill"></i>

        <span>My Badges</span>

    </a>

    <a
        href="<?php echo e(route('student.certificates.index')); ?>"
        class="side-link <?php echo e(request()->routeIs('student.certificates.*') ? 'active' : ''); ?>">

        <i class="bi bi-award"></i>

        <span>My Certificates</span>

    </a>

    <!-- 

    <a
        href="<?php echo e(route('student.dashboard')); ?>#quests"
        class="side-link">

        <i class="bi bi-trophy-fill"></i>

        <span>
            <?php echo e($labels['mission_title'] ?? 'Learning Quests'); ?>

        </span>

    </a> -->



    <a
        href="<?php echo e(route('student.progress')); ?>#progress"
        class="side-link">
        <i class="bi bi-graph-up-arrow"></i>
        <span>My Progress</span>
    </a>

    <a
        href="<?php echo e(route('student.leaderboard')); ?>"
        class="side-link <?php echo e(request()->routeIs('student.leaderboard') ? 'active' : ''); ?>">

        <i class="bi bi-trophy-fill"></i>

        <span>Leaderboard</span>

    </a>

    <a
        href="<?php echo e(route('student.learning-materials.index')); ?>"
        class="side-link <?php echo e(request()->routeIs('student.learning-materials.*') ? 'active' : ''); ?>">

        <i class="bi bi-book-half"></i>

        <span>Learning Materials</span>

    </a>


    <a
        href="<?php echo e(route('student.dashboard')); ?>#topics"
        class="side-link">

        <i class="bi bi-lightbulb-fill"></i>

        <span>AI Topics</span>

    </a>



    

    <div class="nav-category mt-3">

        Identity

    </div>


    <div class="identity-box">


        <div class="identity-top">


            <span class="identity-icon">

                <?php echo e($themeIcon ?? '✦'); ?>


            </span>


            <span class="identity-rank">

                <?php echo e($rankTitle ?? 'Explorer'); ?>


            </span>


        </div>



        <div class="identity-theme">

            <?php echo e(ucfirst($theme ?? 'general')); ?>


            Theme

            <span>•</span>

            <?php echo e(ucfirst($difficulty ?? 'beginner')); ?>


        </div>


    </div>



    

    <div class="sidebar-bottom">


        <form
            action="<?php echo e(route('logout-user')); ?>"
            method="POST">

            <?php echo csrf_field(); ?>


            <button
                type="submit"
                class="side-link logout-link">

                <i class="bi bi-box-arrow-right"></i>

                <span>Log Out</span>

            </button>


        </form>


    </div>


</aside><?php /**PATH C:\xampp\htdocs\gamified-education\resources\views/student/partials/sidebar.blade.php ENDPATH**/ ?>