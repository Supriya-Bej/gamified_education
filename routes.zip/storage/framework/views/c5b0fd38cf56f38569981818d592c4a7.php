

<?php $__env->startSection('title', 'My Certificates'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="mb-4">
            <h1 class="h3">My Certificates</h1>
            <p class="text-secondary mb-0">After completing all three game stages for an interest, your certificate will appear here once an admin approves it.</p>
        </div>

        <div class="row g-3">
            <?php $__empty_1 = true; $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6 col-xl-4">
                    <div class="card h-100 shadow-sm border-0">
                        <div class="card-body">
                            <div class="text-success mb-2"><i class="bi bi-award-fill fs-3"></i></div>
                            <h2 class="h5"><?php echo e($certificate->title); ?></h2>
                            <p class="mb-2"><?php echo e($certificate->task->title); ?></p>
                            <div class="small text-secondary">
                                Issued <?php echo e($certificate->issued_at->format('M d, Y')); ?>

                            </div>
                            <div class="small text-secondary"><?php echo e($certificate->certificate_number); ?></div>
                        </div>
                        <div class="card-footer bg-white border-0">
                            <a class="btn btn-primary" href="<?php echo e(route('student.certificates.show', $certificate)); ?>">
                                View certificate
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="alert alert-info mb-0">
                        No approved certificates yet. Complete all 25 games in each of an interest's three levels, then wait for admin approval.
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <?php if($certificates->hasPages()): ?>
            <div class="mt-4"><?php echo e($certificates->links()); ?></div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gamified-education\resources\views/student/certificates/index.blade.php ENDPATH**/ ?>