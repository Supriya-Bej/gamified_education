
<?php $__env->startSection('title', 'Result'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $quiz = $content->quiz;
        $answers = $attempt->answers ?? [];
    ?>

    <h2><?php echo e($attempt->passed ? '🎉 Quest Complete!' : 'Ektu-r jonno hoyni, abar chesta koro'); ?></h2>

    <p class="fs-4 mb-1">
        Score: <?php echo e($attempt->score); ?>% (<?php echo e($attempt->correct_count); ?>/<?php echo e($attempt->total); ?>)
    </p>

    <?php if($attempt->passed): ?>
        <?php if($attempt->xp_awarded > 0): ?>
            <p class="text-success fs-5">+<?php echo e($attempt->xp_awarded); ?> XP earned</p>
        <?php endif; ?>
        <?php if((int) $attempt->score === 100): ?>
            <div class="alert alert-success">
                Perfect score! Your quest is eligible for an achievement certificate. An admin will review and issue it.
                <?php if($certificate): ?>
                    <a href="<?php echo e(route('student.certificates.show', $certificate->id)); ?>" class="alert-link d-block mt-2">
                        View your certificate
                    </a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <p class="text-secondary">
                You passed! A 100% score qualifies for a certificate. You can retry the quiz without earning XP again.
            </p>
        <?php endif; ?>
    <?php else: ?>
        <p class="text-warning">Pass korte 70% lagbe. Lesson ta abar ekbar poro.</p>
    <?php endif; ?>

    <hr>

    <?php $__currentLoopData = $quiz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $mine = $answers[$i] ?? null;
            $ok = $mine !== null && (int) $mine === (int) $q['answer'];
        ?>

        <div class="q-card">
            <strong>Q<?php echo e($i + 1); ?>. <?php echo e($q['question']); ?></strong>
            <div class="<?php echo e($ok ? 'text-success' : 'text-danger'); ?>">
                <?php echo e($ok ? '✅ Sothik' : '❌ Bhul'); ?>

            </div>

            <?php if($attempt->passed): ?>
                <div class="small text-secondary mt-1">
                    Sothik uttor: <?php echo e($q['options'][$q['answer']]); ?>. <?php echo e($q['explanation']); ?>

                </div>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="d-flex gap-2 mt-3">
        <?php if($attempt->passed): ?>
            <?php if((int) $attempt->score < 100): ?>
                <a href="<?php echo e(route('student.quest.quiz', $task->id)); ?>" class="btn btn-primary">Retry for 100%</a>
            <?php endif; ?>
            <a href="<?php echo e(route('student.dashboard')); ?>" class="btn btn-outline-secondary">Back to Dashboard</a>
        <?php else: ?>
            <a href="<?php echo e(route('student.quest.show', $task->id)); ?>" class="btn btn-outline-secondary">Lesson abar poro</a>
            <a href="<?php echo e(route('student.quest.quiz', $task->id)); ?>" class="btn btn-primary">Retry Quiz</a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('quest.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\gamified-education\resources\views/quest/result.blade.php ENDPATH**/ ?>